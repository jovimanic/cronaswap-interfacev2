import { default as Default } from './Default'
import { default as Miso } from './Miso'

const Layout = { Default, Miso }

export default Layout

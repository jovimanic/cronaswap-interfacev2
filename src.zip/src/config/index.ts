import { ChainId } from '@cronaswap/core-sdk'

const config = {
  [ChainId.ETHEREUM]: {},
}

export const CRO_BLOCK_TIME = 6

export default config

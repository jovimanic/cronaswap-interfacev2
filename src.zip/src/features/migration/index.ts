import { ChainId } from '@cronaswap/core-sdk'

export const MigrationSupported = [ChainId.ETHEREUM, ChainId.CRONOS]
